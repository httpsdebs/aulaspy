/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vendedor;

/**
 *
 * @author logon
 */
public class Vendedor {
    String nome;
    float salario;
    int idade;

    void imprimirNome(){
        System.out.println("O nome é " + nome);
}
     void imprimirIdade(){
        System.out.println("A idade é " + idade);
}
    void imprimirSalario(){
        System.out.println("O salario é " + salario);
}
    float imprimirBonus(){
        float bonus = salario + (salario * 0.10f);
        
        return bonus;
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        Vendedor anitta = new Vendedor();
        Vendedor bruno = new Vendedor();
        Vendedor neymar = new Vendedor();

        anitta.salario = 120.45f;
        anitta.imprimirBonus();

        bruno.salario = 345.07f;
        bruno.imprimirBonus();

        neymar.salario = 456.12f;
        float bonusCalculado = neymar.imprimirBonus();

        System.out.println("bonus " + bonusCalculado);
        System.out.println("o bonus é " + neymar.imprimirBonus());

    }
    
}
