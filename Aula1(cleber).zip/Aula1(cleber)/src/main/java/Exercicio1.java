
import javax.swing.JOptionPane;

public class Exercicio1 {
    
    

public static void main(String[] args) {
   //comando print
        System.out.println("qualquer coisa");
 //declaração de variavel
            int idade;
            double pi;
            float peso;
            
 //atribuição de valor
            idade = 17;
            pi = 3.1425;
            int valor =12;
            String nome;
            nome = "cleber";
                    

                System.out.println("olá " + nome);
            
            String email ="cleber@gmail.com";
            String coracao = "coração";
            boolean casado;
            casado = false;
            String ag;
            ag = JOptionPane.showInputDialog("insira a sua agência");
}

}
