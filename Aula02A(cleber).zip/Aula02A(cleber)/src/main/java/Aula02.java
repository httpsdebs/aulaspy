
import javax.swing.JOptionPane;


public class Aula02 {

    public static void main(String[] args) {
    /*    
     float valorCompra =  Float.parseFloat
  (JOptionPane.showInputDialog("Insira o valor da compra"));

     float descontoEmReais = valorCompra * 0.10f;

     float valorPago = valorCompra - descontoEmReais;

    JOptionPane.showMessageDialog
(null, "O valor pago será " + valorPago);




// Programa para saber se o aluno foi aprovado ou reprovado
   float nota1 =   Float.parseFloat
(JOptionPane.showInputDialog("Insira a nota 1"));

 float nota2 =   Float.parseFloat
(JOptionPane.showInputDialog("Insira a nota 2"));

float media = (nota1 + nota2) / 2 ;

JOptionPane.showMessageDialog(null, "A média é " +  media);

if (media > 6){
    System.out.println("Aprovado");
}else{
    System.out.println("Reprovado");
}  


// Este programa diz se a pessoa pode tirar cnh ou não
int idade = Integer.parseInt
(JOptionPane.showInputDialog("Insira a sua idade"));

if (idade >= 18 ){
    System.out.println("Você pode tirar a cnh");
}else{
    System.out.println("Você não pode tirar a cnh");
}
*/

int idade = Integer.parseInt
(JOptionPane.showInputDialog("Insira a sua idade"));

if (idade == 10){
    System.out.println("Criança ");
}

if (idade == 27){
    System.out.println("Adolescente");
}

if (idade >= 25){
    System.out.println("Adulto");
}


    }
}
