/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula5;

/**
 *
 * @author logon
 */
public class Aula5 {
        String nome, cpf, estadoCivil;
        int idade;
   
        void pensar(){
            System.out.println("Pensando...");
};

        void correr(){
            System.out.println("Correndo...");
};  

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Aula5 pedro = new Aula5();
    Aula5 bill = new Aula5();

    pedro.nome        = "Pedro";
    pedro.estadoCivil = "Casado";   
    pedro.cpf         = "123.456.678-00";
    pedro.idade       = 20;

        System.out.println("O nome é " + pedro.nome);
        System.out.println("O estado civil é " + pedro.estadoCivil);
        System.out.println("O cpf é " + pedro.cpf);
        System.out.println("A idade é " + pedro.idade);




    pedro.correr();
    bill.correr();    
    }
    
}
