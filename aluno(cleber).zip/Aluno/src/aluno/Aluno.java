/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aluno;

/**
 *
 * @author logon
 */
public class Aluno {
    String nome;
    int ra;
    double mensalidade;
    String periodo;
    String universidade;

    Aluno(){
       periodo      = "noite";
       universidade = "unicsul";
}
     Aluno(String Pperiodo, String Puniversidade){
       periodo      = Pperiodo;
       universidade = Puniversidade;
       
}

    void imprimirNome(){
        System.out.println("nome é " + nome);
}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Aluno cleber = new Aluno();
        cleber.nome         = "cleber";
        cleber.mensalidade  = 600.01;
        cleber.periodo      = "manhã";
        cleber.universidade = "unicsul";

        Aluno anitta = new Aluno();
      
        System.out.println("Periodo da anitta " + anitta.periodo);

        Aluno bruno = new Aluno("manha", "unicsul");

    }
    
}
