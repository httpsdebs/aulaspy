
package Automoveis;

import aula07.Aluno;


public class Carro {
    
    public static void main(String[] args) {
        Aluno aluno = new Aluno();
        Aluno pedro = new Aluno("Pedrinho");
        pedro.setNota1(9);
        
       
        
    
    }
    
}
