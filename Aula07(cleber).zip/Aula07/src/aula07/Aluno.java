package aula07;

public class Aluno {

    private String nome;
    private double nota1;
    private double nota2;
    private int ra;
    private double mensalidade;
        
    public Aluno(){
    }
    
    public Aluno(String nome){
        this.nome = nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public void setNota1(double nota1){
        if (nota1 >= 0){
            this.nota1 = nota1;
        }
    }
    
    public void setNota2(double nota2){
        this.nota2 = nota2;
    }
    
    public void setRa(int ra){
        this.ra = ra;
    }
    
    public void setMensalidade(double mensalidade){
        this.mensalidade = mensalidade;
    }
    
    public String getNome(){
        return nome;
    }
    
    public double getNota1(){
        return nota1;
    }
    
    public double getNota2(){
        return nota2;
    }
    
    public int getRa(){
        return ra;
    }
    
    public double getMensalidade(){
        return mensalidade;
    }
    
    
}
