/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication9;

import java.time.Clock;
import javax.swing.JOptionPane;


/**
 *
 * @author logon
 */
public class JavaApplication9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
/*
        // TODO code application logic here
      float salario = Float.parseFloat

(JOptionPane.showInputDialog("insira o salário:"));

      int codigo = Integer.parseInt
(JOptionPane.showInputDialog("insira o código:"));

      float bonus, salarioAtual;

      switch(codigo){
      case 1:
           bonus = salario *0.2f;
           salarioAtual = bonus + salario;
           System.out.println ("o salario do programador será" + salarioAtual);
           break;
      case 2:
           bonus = salario *0.15f;
           salarioAtual= bonus + salario;
           System.out.println ("o salario do Analista de rede será" + salarioAtual);
           break;
      case 3:
           bonus = salario *0.05f;
           salarioAtual = bonus + salario;
           System.out.println ("o salario do gerente de projeto será" + salarioAtual);
           break;
      case 4:
           System.out.println ("o salario do diretor será" + salario);
           break;
      default:
           System.out.println("código inválido");
}

    float a = Float.parseFloat(JOptionPane.showInputDialog("insira o lado a:"));
    float b = Float.parseFloat(JOptionPane.showInputDialog("insira o lado b:"));
    float c = Float.parseFloat(JOptionPane.showInputDialog("insira o lado c:"));
    
    if (a == b && a == c ){
               System.out.println("equilátero");
    }else{
          if(a == b || a == c || b == c){
              System.out.println("isósceles");
         }else{
              System.out.println("escaleno");
        }
}
*/
    for(int i = 0; 1 < 4;i++){
          System.out.println("oiiii...");
}
   }


 }
