package exercicios;

import java.util.Scanner;

public class Paciente {
    
    private String nome;
    private String rg;
    private String endereco;
    private String telefone;
    private String dataNascimento;
    private String profissao;

    public Paciente() {
    }

    public Paciente(String nome, String rg, String endereco, String telefone, String dataNascimento, String profissao) {
        this.nome = nome;
        this.rg = rg;
        this.endereco = endereco;
        this.telefone = telefone;
        this.dataNascimento = dataNascimento;
        this.profissao = profissao;
    }

    public Paciente(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setProfissao(String profissao) {
        this.profissao = profissao;
    }
    


    public static void main(String[] args) {
        
        Scanner leia = new Scanner(System.in);

        String nome;        
        System.out.println("Insira o nome");
        nome = leia.nextLine();
        
        System.out.println("Nome " +  nome);
        

        Paciente paciente1 = new Paciente(nome);
        
    }
}
