
package aula06;

public class Aula06 {

    public static void main(String[] args) {
        
        Professor cleber = new Professor();
                
        cleber.nome        ="Cleber";
        cleber.idade       = 16;
        cleber.disciplinas = "POO";
        
        System.out.println("Nome " + cleber.nome);
        System.out.println("Idade " + cleber.idade);
        System.out.println
        ("Disciplina " + cleber.disciplinas);

        
        Professor maria = new Professor();
        System.out.println("Nome "  + maria.nome);
        System.out.println("Idade " + maria.idade);
        
        Professor claudio = new Professor();
        System.out.println("Nome "  + claudio.nome);
        System.out.println("Idade " + claudio.idade);
        
        
        Professor pedro = new Professor("Pedro", 74);
        System.out.println("Nome " + pedro.nome);
        System.out.println("Idade " + pedro.idade);
        
        Professor willian = new Professor("Pablo", 65);
        
        willian.nome = "willian";
        willian.idade = 78;
        
        System.out.println("Nome " + willian.nome);
        System.out.println("Idade " + willian.idade);
        
        
    }
    
}
