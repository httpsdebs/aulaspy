package aula06;

public class Professor {
    String nome;
    int    idade;
    double salario;
    String disciplinas;
    
    Professor(){
        nome = "João";
        idade = 31;
        disciplinas = "matemática";
    }
    
    Professor(String pNome, int pIdade){
        nome = pNome;
        idade = pIdade;
    }
    
    
    void ensinar(){
        System.out.println("Ensinando....");
    }   
}
