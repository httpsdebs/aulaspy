package aula06;

public class Aluno {
   
}
